

return function (_ENV, _module)
local exports, module = _module.exports, _module;


--[[0]] process.stdin:resume();
--[[24]] process.stdin:on(("data"), (function (this, buf)
--[[66]] console:log(buf);
--[[84]] process.stdin:pause();
end));

return _module.exports;
end 
