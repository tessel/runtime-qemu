

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap, l = tap, l;
--[[0]] tap = require(_global, ("../tap")); 
--[[30]] tap:count((1));
--[[45]] l = _arr({[0]=nil, (1)}, 2); 
--[[59]] tap:eq(l[(1)], (1), ("empty elements allowed"));

return _module.exports;
end 
