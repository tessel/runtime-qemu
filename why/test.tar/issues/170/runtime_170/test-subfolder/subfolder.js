

return function (_ENV, _module)
local exports, module = _module.exports, _module;


--[[0]] module.exports = require(_global, ("../../test"));

return _module.exports;
end 
