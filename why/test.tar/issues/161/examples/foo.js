

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local test = test;
--[[0]] test = require(_global, ("test")); 

return _module.exports;
end 
