

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap = tap;
--[[0]] tap = require(_global, ("../tap")); 
--[[30]] tap:count((1));
--[[45]] tap:eq(process:umask(), parseInt(_global, ("0022"), (8)));

return _module.exports;
end 
