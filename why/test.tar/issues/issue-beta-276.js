

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap, a, a, a__val, b = tap, a, a, a__val, b;
--[[0]] tap = require(_global, ("../tap")); 
--[[30]] tap:count((2));
--[[45]] a = _new(Date); 
--[[65]] tap:eq(((a)-(a)), (0));
--[[84]] a = _new(Date); 
--[[104]] a__val = Number(_global, a); 
--[[127]] b = _obj({
  ["valueOf"]=(function (this)
--[[163]] if true then return ((a__val)-((1000))); end
end)
}); 
--[[189]] tap:eq(((a)-(b)), (1000));

return _module.exports;
end 
