

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap = tap;
--[[0]] tap = require(_global, ("../tap")); 
--[[30]] tap:count((1));
--[[44]] tap:eq(_arr({[0]=("a"), ("b"), _obj({
  
})}, 3):join(("/")), ("a/b/[object Object]"), ("object in array passes Array.prototype.join"));

return _module.exports;
end 
