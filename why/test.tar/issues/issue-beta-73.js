

return function (_ENV, _module)
local exports, module = _module.exports, _module;


--[[0]] if (not ((function (this)
local n, u, t = n, u, t;
n = (function () local n = nil; n = function (this, n)
local e, l, o, r, i, f, c, a, p, d, s, m = e, l, o, r, i, f, c, a, p, d, s, m;
e = (function () local e = nil; e = function (this)
local u, e, o = u, e, o;
--[[39]] 
while (function () local _r =  ((((a)<(c.length)))and(((n)>(p)))); i  = _r; return _r; end)() do 

--[[64]] u = (function () local _r = a; a = _r + 1; return _r; end)();  e = c[u];  o = t:call(e, (1)); 
--[[95]] if _seq({o:push(l(_global, u)), (function () local _r = p + 1; p = _r; return _r; end)(), e[(0)]:apply((null), o)}) then end;


end;
end; e:__defineGetter__("name", function () return "e"; end); return e; end)();

l = (function () local l = nil; l = function (this, n)
--[[146]] if true then return (function (this, u, t)
--[[167]] if _seq({(function () local _r = p - 1; p = _r; return _r; end)(), (((((null))==(s)))and((((((null))~=(u))) and {_seq({(function () local _r =  u; s  = _r; return _r; end)(), (function () local _r =  (function () local _r =  (((0))/((0))); d  = _r; return _r; end)(); a  = _r; return _r; end)(), o(_global)})} or {_seq({(function () local _r =  t; c[n]  = _r; return _r; end)(), (((function () local _r = d - 1; d = _r; return _r; end)()) and {((i)or(e(_global)))} or {o(_global)})[1]})})[1]))}) then end;
end); end
end; l:__defineGetter__("name", function () return "l"; end); return l; end)();

o = (function () local o = nil; o = function (this)
--[[246]] if (((((null))~=(s))) and {m(_global, s)} or {((f) and {m(_global, s, c)} or {m:apply((null), _arr({[0]=s}, 1):concat(c))})[1]})[1] then end;
end; o:__defineGetter__("name", function () return "o"; end); return o; end)();
--[[26]] 
--[[132]] 
--[[233]] 
--[[296]] r = nil;  i = nil;  f = nil;  c = _arr({}, 0);  a = (0);  p = (0);  d = (0);  s = (null);  m = u; 
--[[334]] if true then return _seq({((n)or((function () local _r =  (((1))/((0))); n  = _r; return _r; end)())), (function () local _r =  _obj({
  ["defer"]=(function (this, ...)
local arguments = _arguments(...);
--[[372]] if true then return _seq({((s)or(_seq({c:push(arguments), (function () local _r = d + 1; d = _r; return _r; end)(), e(_global)}))), r}); end
end),
  ["await"]=(function (this, n)
--[[431]] if true then return _seq({(function () local _r =  n; m  = _r; return _r; end)(), (function () local _r =  (not ((1))); f  = _r; return _r; end)(), ((d)or(o(_global))), r}); end
end),
  ["awaitAll"]=(function (this, n)
--[[478]] if true then return _seq({(function () local _r =  n; m  = _r; return _r; end)(), (function () local _r =  (not ((0))); f  = _r; return _r; end)(), ((d)or(o(_global))), r}); end
end)
}); r  = _r; return _r; end)()}); end
end; n:__defineGetter__("name", function () return "n"; end); return n; end)();

u = (function () local u = nil; u = function (this)

end; u:__defineGetter__("name", function () return "u"; end); return u; end)();
--[[12]] 
--[[505]] 
--[[519]] t = _arr({}, 0).slice; 
--[[534]] if _seq({(function () local _r =  ("1.0.7"); n.version  = _r; return _r; end)(), ((((((("function"))==((_typeof(define)))))and(define.amd))) and {define(_global, (function (this)
--[[608]] if true then return n; end
end))} or {((((((("object"))==((_typeof(module)))))and(module.exports))) and {(function () local _r =  n; module.exports  = _r; return _r; end)()} or {(function () local _r =  n; this.queue  = _r; return _r; end)()})[1]})[1]}) then end;
end)(_global))) then end;

return _module.exports;
end 
