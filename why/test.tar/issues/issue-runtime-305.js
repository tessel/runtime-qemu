

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap = tap;
--[[0]] tap = require(_global, ("../tap")); 
--[[29]] tap:count((1));
--[[43]] tap:eq(((global["_G"])and(global["_G"]["_HSMATCH"])), (null), ("_HSMATCH object should not be accessible"));

return _module.exports;
end 
