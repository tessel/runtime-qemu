

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap = tap;
--[[0]] tap = require(_global, ("../tap")); 
--[[30]] tap:count((1));
--[[45]] console:log(_bit.lshift(_G.tointegervalue((true)),_G.tointegervalue((1))));
--[[69]] console:log(_bit.lshift(_G.tointegervalue((_G.tonumbervalue((true)))),_G.tointegervalue((1))));
--[[95]] tap:ok((true));

return _module.exports;
end 
