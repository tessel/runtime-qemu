

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap = tap;
--[[0]] tap = require(_global, ("../tap")); 
--[[29]] tap:count((1));
--[[43]] tap:eq(JSON:stringify(_obj({
  ["foo"]=(1)
}), (null), (2)), ("{\010  \"foo\": 1\010}"), ("Integer space argument in stringify."));

return _module.exports;
end 
