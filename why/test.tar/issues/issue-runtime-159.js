

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap, mAccelLast, delta = tap, mAccelLast, delta;
--[[0]] tap = require(_global, ("../tap")); 
--[[29]] tap:count((1));
--[[43]] mAccelLast = nil; 
--[[59]] delta = (((20))-(mAccelLast)); 
--[[116]] tap:ok((true));

return _module.exports;
end 
