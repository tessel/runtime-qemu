

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap, dash, underscore = tap, dash, underscore;
--[[0]] tap = require(_global, ("../tap")); 
--[[29]] tap:count((2));
--[[43]] dash = require(_global, ((____dirname)+(("/170/runtime-170/test-subfolder/subfolder")))); 
--[[120]] tap:eq(dash, (true));
--[[140]] underscore = require(_global, ((____dirname)+(("/170/runtime_170/test-subfolder/subfolder")))); 
--[[223]] tap:eq(underscore, (true));

return _module.exports;
end 
