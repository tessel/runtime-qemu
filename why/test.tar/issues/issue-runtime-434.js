

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap = tap;
--[[0]] tap = require(_global, ("../tap")); 
--[[29]] tap:count((5));
--[[44]] tap:ok((not ((((null))<(_obj({
  
}))))));
--[[65]] tap:ok((not (((_obj({
  
}))>((null))))));
--[[86]] tap:ok((not (((_obj({
  
}))<(_obj({
  
}))))));
--[[105]] tap:ok((not (((_obj({
  
}))>(_obj({
  
}))))));
--[[124]] tap:ok((true), ("null comparisons succeed without erroring out."));

return _module.exports;
end 
