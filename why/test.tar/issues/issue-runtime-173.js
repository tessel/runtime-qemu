

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap, c = tap, c;
--[[0]] tap = require(_global, ("../tap")); 
--[[29]] tap:count((1));
--[[43]] c = _bit.bxor(_G.tointegervalue((3988292384)),_G.tointegervalue((62317068))); 
--[[74]] console:log(("#"), c);
--[[95]] tap:ok(((c)<((0))));

return _module.exports;
end 
