

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap, a = tap, a;
local _regex0 = _regexp("^\\s*$", "");
--[[0]] tap = require(_global, ("../tap")); 
--[[30]] tap:count((1));
--[[45]] a = _regex0; 
--[[63]] tap:ok((true));

return _module.exports;
end 
