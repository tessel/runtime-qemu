

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap = tap;
--[[0]] tap = require(_global, ("../tap")); 
--[[29]] tap:count((1));
--[[43]] tap:eq(_arr({[0]=(0), (1)}, 2):join((",")), ("0,1"), ("[0,1].join() does not omit 0"));

return _module.exports;
end 
