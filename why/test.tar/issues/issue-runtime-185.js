

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap = tap;
--[[0]] tap = require(_global, ("../tap")); 
--[[29]] tap:count((7));
--[[43]] tap:eq(("canal"):lastIndexOf(("a")), (3));
--[[80]] tap:eq(("canal"):lastIndexOf(("a"), (2)), (1));
--[[119]] tap:eq(("canal"):lastIndexOf(("l"), (4)), (4));
--[[158]] tap:eq(("canal"):lastIndexOf(("a"), (0)), (-((1))));
--[[198]] tap:eq(("canal"):lastIndexOf(("a"), (8)), (-((1))));
--[[238]] tap:eq(("canal"):lastIndexOf(("a"), (-((5)))), (-((1))));
--[[279]] tap:eq(("canal"):lastIndexOf(("x")), (-((1))));

return _module.exports;
end 
