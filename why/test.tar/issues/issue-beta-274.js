

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap = tap;
--[[0]] tap = require(_global, ("../tap")); 
--[[30]] tap:count((2));
--[[45]] tap:ok(_bit.bxor(_G.tointegervalue((2)),_G.tointegervalue((((16))==((16))))), ("bitwise xor"));
--[[79]] tap:ok(_bit.bxor(_G.tointegervalue((2)),_G.tointegervalue((((16))~=((65536))))), ("not exponent"));

return _module.exports;
end 
