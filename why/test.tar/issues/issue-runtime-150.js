

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap = tap;
--[[0]] tap = require(_global, ("../tap")); 
--[[29]] tap:count((3));
--[[42]] console:log(("#"), JSON:stringify(("/"):slice((0), (-((1))))));
--[[93]] tap:eq(("/"):slice((0), (-((1)))), (""));
--[[123]] tap:eq(("12345"):slice((0), (-((3)))), ("12"));
--[[159]] tap:eq(("12345"):slice((0), (-((100)))), (""));

return _module.exports;
end 
