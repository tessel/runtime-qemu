

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local opts, n = opts, n;
--[[52]] opts = _obj({
  
}); 
--[[66]] for n in _pairs(opts) do 
n = ""+n; 

end;
--[[91]] local _e, _noreturn = nil, {}
local _s, _r = _xpcall(function ()

      if true then return _noreturn; end
    end, function (err)
        _e = err
    end);
if _s == false then
e = _e;
_r = (function ()

  if true then return _noreturn; end
end)();
end;

if _r ~= _noreturn then
  return _r
end;

return _module.exports;
end 
