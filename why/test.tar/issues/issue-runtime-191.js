

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap = tap;
--[[0]] tap = require(_global, ("../tap")); 
--[[29]] tap:count((1));
--[[43]] tap:eq(JSON:stringify(_obj({
  
}), (null), ("  ")), ("{}"), ("If partial is empty, then let final be \"{}\"."));

return _module.exports;
end 
