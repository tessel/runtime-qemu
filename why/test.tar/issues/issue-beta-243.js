

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap = tap;
--[[23]] tap = require(_global, ("../tap")); 
--[[53]] tap:count((1));
--[[67]] tap:ok((true));

return _module.exports;
end 
