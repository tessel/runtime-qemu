

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap, a = tap, a;
--[[52]] tap = require(_global, ("../tap")); 
--[[81]] tap:count((1));
--[[95]] a = _obj({
  
}); 
--[[106]] a.NaN = (((0))/((0)));
--[[118]] a.nan = (((0))/((0)));
--[[130]] a[("-NaN")] = (((0))/((0)));
--[[146]] a[("-nan")] = (((0))/((0)));
--[[162]] a.Infinity = (((0))/((0)));
--[[179]] a.infinity = (((0))/((0)));
--[[196]] a[("-Infinity")] = (((0))/((0)));
--[[217]] a[("-infinity")] = (((0))/((0)));
--[[239]] tap:ok((true));

return _module.exports;
end 
