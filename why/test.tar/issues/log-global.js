

return function (_ENV, _module)
local exports, module = _module.exports, _module;


--[[0]] console:log(global);

return _module.exports;
end 
