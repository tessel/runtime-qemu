

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local tap, elem, n = tap, elem, n;
--[[125]] tap = require(_global, ("../tap")); 
--[[155]] tap:count((2));
--[[170]] elem = ("2"); 
--[[186]] tap:eq(((("0"))+(elem)), ("02"));
--[[212]] console:log(("#"), ((("0"))+(elem)));
--[[242]] n = Number(_global, ("55")); 
--[[264]] tap:eq(n, (55));
--[[279]] console:log(("#"), n);

return _module.exports;
end 
