

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local async = async;
--[[0]] async = require(_global, ("async")); 
--[[30]] console:log(("async required."));

return _module.exports;
end 
