

return function (_ENV, _module)
local exports, module = _module.exports, _module;


--[[314]] console:error(("1..4"));
--[[337]] console:info(("ok"));
--[[357]] console:warn(("ok"));
--[[377]] console:error(("ok"));
--[[398]] console:log(("ok"));

return _module.exports;
end 
