

return function (_ENV, _module)
local exports, module = _module.exports, _module;


--[[32]] if true then return (5); end

return _module.exports;
end 
