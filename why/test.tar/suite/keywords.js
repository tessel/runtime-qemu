

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local a, _K_repeat = a, _K_repeat;
--[[0]] console:log(("1..2"));
--[[43]] a = _obj({
  
}); 
--[[55]] a["and"] = (1);
--[[66]] a["break"] = (1);
--[[79]] a["do"] = (1);
--[[89]] a["else"] = (1);
--[[101]] a["elseif"] = (1);
--[[115]] a["end"] = (1);
--[[126]] a["false"] = (1);
--[[139]] a["for"] = (1);
--[[150]] a["function"] = (1);
--[[166]] a["if"] = (1);
--[[176]] a["in"] = (1);
--[[186]] a["local"] = (1);
--[[199]] a["nil"] = (1);
--[[210]] a["not"] = (1);
--[[221]] a["or"] = (1);
--[[231]] a["repeat"] = (1);
--[[245]] a["return"] = (1);
--[[259]] a["then"] = (1);
--[[271]] a["true"] = (1);
--[[283]] a["until"] = (1);
--[[296]] a["while"] = (1);
--[[309]] a.error = (1);
--[[323]] console:log(("ok"), (1));
--[[345]] _K_repeat = nil; 
--[[357]] _K_repeat = (true);
--[[372]] while _K_repeat do 

--[[393]] _K_repeat = (false);

end;
--[[411]] _K_repeat = (true);
--[[426]] 
while _K_repeat do 

--[[445]] _K_repeat = (false);


end;
--[[463]] repeat 



until not (_K_repeat); 
--[[487]] console:log(("ok"));

return _module.exports;
end 
