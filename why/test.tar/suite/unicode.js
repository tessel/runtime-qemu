

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local a = a;
--[[0]] a = ("z\226\152\131"); 
--[[24]] console:log(a);

return _module.exports;
end 
