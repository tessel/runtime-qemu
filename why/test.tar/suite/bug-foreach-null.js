

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local a = a;
--[[0]] a = _arr({[0]=(1), (2), (3)}, 3); 
--[[20]] console:log(("1..1"));
--[[40]] a:forEach((function (this, b)
--[[66]] if ((b)==((null))) then
--[[85]] console:log(("not ok"));
--[[110]] process:exit((1));
end;
end));
--[[133]] console:log(("ok"));

return _module.exports;
end 
