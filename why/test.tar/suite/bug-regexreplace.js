

return function (_ENV, _module)
local exports, module = _module.exports, _module;


local val = val;
local _regex0 = _regexp("(..)", "g");
--[[0]] console:log(("1..1"));
--[[20]] val = ("aa"):replace(_regex0, ("\\$1\\$1\\$1")); 
--[[69]] console:log(((((val)==(("\\aa\\aa\\aa")))) and {("ok")} or {("not ok")})[1]);
--[[122]] console:log(("#"), val);

return _module.exports;
end 
