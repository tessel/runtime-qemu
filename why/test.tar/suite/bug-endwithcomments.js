

return function (_ENV, _module)
local exports, module = _module.exports, _module;


--[[0]] Math:min((5), (5));

return _module.exports;
end 
